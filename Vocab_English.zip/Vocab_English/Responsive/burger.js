document.addEventListener('DOMContentLoaded', () => {
    const burgerMenu = document.querySelector('.burger-menu');
    const sidebar = document.querySelector('.sidebar');
    const content = document.querySelector('.content');
    const overlay = document.querySelector('.sidebar-overlay');

    console.log('Burger:', burgerMenu, 'Sidebar:', sidebar, 'Content:', content, 'Overlay:', overlay);

    if (!burgerMenu || !sidebar || !content || !overlay) {
        console.error('Không tìm thấy một hoặc nhiều phần tử cần thiết');
        return;
    }

    burgerMenu.addEventListener('click', () => {
        console.log('Burger clicked');
        toggleSidebar();
    });

    overlay.addEventListener('click', () => {
        console.log('Overlay clicked');
        toggleSidebar();
    });
});

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const content = document.querySelector('.content');
    const burgerMenu = document.querySelector('.burger-menu');
    const overlay = document.querySelector('.sidebar-overlay');

    if (!sidebar || !content || !burgerMenu || !overlay) {
        console.error('Không tìm thấy các elements cần thiết trong toggleSidebar');
        return;
    }

    const isOpening = !sidebar.classList.contains('active');
    console.log('Toggling sidebar, isOpening:', isOpening);

    if (window.matchMedia('(max-width: 992px)').matches) {
        sidebar.classList.toggle('active');
        content.classList.toggle('sidebar-active');
        burgerMenu.classList.toggle('active');
        overlay.classList.toggle('active');

        burgerMenu.innerHTML = isOpening 
            ? '<i class="fas fa-times"></i>' 
            : '<i class="fas fa-bars"></i>';

        document.body.style.overflow = isOpening ? 'hidden' : '';
    }
}

window.addEventListener('resize', () => {
    if (window.matchMedia('(min-width: 993px)').matches) {
        const sidebar = document.querySelector('.sidebar');
        const content = document.querySelector('.content');
        const overlay = document.querySelector('.sidebar-overlay');
        const burgerMenu = document.querySelector('.burger-menu');

        if (sidebar && sidebar.classList.contains('active')) {
            sidebar.classList.remove('active');
            content.classList.remove('sidebar-active');
            burgerMenu.classList.remove('active');
            overlay.classList.remove('active');
            burgerMenu.innerHTML = '<i class="fas fa-bars"></i>';
            document.body.style.overflow = '';
        }
    }
});