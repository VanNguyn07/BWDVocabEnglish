// Gán sự kiện cho nút Tra Từ với ID
document.getElementById("searchButton").addEventListener("click", () => {
  const word = document.getElementById("search").value.trim().toLowerCase();
  if (word) {
    loadSearchWord(word);
  }
});

document.getElementById("search").addEventListener("keypress", (event) => {
  if (event.key === "Enter") {
    const word = document.getElementById("search").value.trim().toLowerCase();
    if (word) {
      loadSearchWord(word);
    }
  }
});

// Hàm tải nội dung từ searchWord.html và tra từ
async function loadSearchWord(word) {
  try {
    // Lấy nội dung từ searchWord.html (điều chỉnh đường dẫn nếu cần)
    const response = await fetch('searchWord/searchWord.html');
    if (!response.ok) {
      throw new Error(`Không thể tải file searchWord.html. Trạng thái: ${response.status}`);
    }
    const htmlContent = await response.text();

    // Thêm nội dung vào container
    const container = document.getElementById("searchWordContainer");
    container.innerHTML = htmlContent;
    const searchAdvanced = document.getElementById("searchAdvanced");
    if (!searchAdvanced) {
      throw new Error("Không tìm thấy #searchAdvanced trong nội dung tải về.");
    }
    searchAdvanced.classList.remove("hidden");

    // Hiển thị lớp phủ
    const overlay = document.getElementById("overlay");
    overlay.classList.remove("hidden");

    // Gọi hàm tra từ
    searchWord(word);

    // Thêm sự kiện ẩn khi nhấp ngoài (đảm bảo chỉ hoạt động trên overlay)
    overlay.removeEventListener("click", hideSearchWord); // Loại bỏ sự kiện cũ
    overlay.addEventListener("click", hideSearchWord);
    searchAdvanced.addEventListener("click", (e) => {
      e.stopPropagation(); // Ngăn sự kiện lan ra overlay khi nhấp vào #searchAdvanced
    });

  } catch (error) {
    console.error("Lỗi khi tải hoặc hiển thị nội dung:", error);
    const container = document.getElementById("searchWordContainer");
    container.innerHTML = `<p>Đã xảy ra lỗi: ${error.message}</p>`;
  }
}

// Hàm tìm kiếm từ vựng
async function searchWord(word) {
  const wordDisplay = document.getElementById("word");
  const vocabMeaning = document.getElementById("vocabMeaning");
  const vocabExample = document.getElementById("vocabExample");
  const vocabWordType = document.getElementById("vocabWordType");
  const phonetic = document.getElementById("phonetic");
  let phoneticBtn = document.getElementById("PhoneticBtn");

  // Reset UI nếu không có từ
  if (!word) {
    wordDisplay.innerHTML = "";
    vocabMeaning.textContent = "Vui lòng nhập từ cần tra.";
    vocabExample.textContent = "Ví dụ: ";
    vocabWordType.textContent = "Từ Loại: ";
    phonetic.textContent = "...";
    if (phoneticBtn) phoneticBtn.replaceWith(phoneticBtn.cloneNode(true)); // Reset event listener
    return;
  }

  // Hiển thị trạng thái đang tìm
  wordDisplay.innerHTML = `<b>${word}</b>`;
  vocabMeaning.textContent = "Đang tìm...";
  vocabExample.textContent = "Ví dụ: ";
  vocabWordType.textContent = "Từ Loại: ";
  phonetic.textContent = "...";

  try {
    // 1. Gọi Free Dictionary API
    const dictRes = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
    if (!dictRes.ok) throw new Error("Không thể truy cập API từ điển");
    const dictData = await dictRes.json();

    // Kiểm tra lỗi từ API
    if (!Array.isArray(dictData) || dictData.length === 0 || dictData[0].title === "No Definitions Found") {
      wordDisplay.innerHTML = `<b>${word}</b>`;
      vocabMeaning.textContent = `Không tìm thấy từ "${word}"`;
      vocabExample.textContent = "Ví dụ: Không có";
      vocabWordType.textContent = "Từ Loại: Không có";
      phonetic.textContent = "Không có";
      if (phoneticBtn) phoneticBtn.replaceWith(phoneticBtn.cloneNode(true)); // Reset event listener
      return;
    }

    const wordData = dictData[0];

    // Lấy thông tin từ API
    const phoneticText = wordData.phonetics.find(p => p.text)?.text || "Không có";
    const audioUrl = wordData.phonetics.find(p => p.audio)?.audio || "";

    // Lấy từ loại và ví dụ
    let wordType = "Không có";
    let example = "Không có ví dụ";
    if (wordData.meanings && wordData.meanings.length > 0) {
      const firstMeaning = wordData.meanings[0];
      wordType = firstMeaning.partOfSpeech || "Không có";
      const firstDef = firstMeaning.definitions[0] || {};
      example = firstDef.example || "Không có ví dụ";
    }

    // 2. Dịch nghĩa bằng MyMemory API
    const translateRes = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(word)}&langpair=en|vi`);
    if (!translateRes.ok) throw new Error("Không thể truy cập API dịch");
    const translateData = await translateRes.json();
    let vietnamese = translateData.responseData?.translatedText || "Không thể dịch";

    // Cải thiện dịch nghĩa
    if (vietnamese.includes("điều") && vietnamese.length < 10) {
      vietnamese = vietnamese.replace("điều ", "").trim();
    }

    // 3. Hiển thị kết quả
    wordDisplay.innerHTML = `<b>${word}</b>`;
    vocabMeaning.textContent = `Nghĩa: ${vietnamese}`;
    vocabExample.textContent = `Ví dụ: ${example}`;
    vocabWordType.textContent = `Từ Loại: ${wordType.charAt(0).toUpperCase() + wordType.slice(1)}`;
    phonetic.textContent = phoneticText;

    // 4. Gán sự kiện phát âm
    if (phoneticBtn) phoneticBtn.replaceWith(phoneticBtn.cloneNode(true)); // Reset event listener
    phoneticBtn = document.getElementById("PhoneticBtn"); // Cập nhật tham chiếu
    phoneticBtn.addEventListener("click", () => playSound(audioUrl, word));

  } catch (error) {
    console.error("Lỗi:", error);
    wordDisplay.innerHTML = `<b>${word}</b>`;
    vocabMeaning.textContent = `Đã xảy ra lỗi: ${error.message}`;
    vocabExample.textContent = "Ví dụ: ";
    vocabWordType.textContent = "Từ Loại: ";
    phonetic.textContent = "...";
    if (phoneticBtn) phoneticBtn.replaceWith(phoneticBtn.cloneNode(true)); // Reset event listener
  }
}

// Hàm ẩn giao diện searchWord
function hideSearchWord() {
  const container = document.getElementById("searchWordContainer");
  const overlay = document.getElementById("overlay");
  container.innerHTML = ""; // Xóa nội dung
  overlay.classList.add("hidden");
}

// Hàm debounce
function debounce(func, wait) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

// Hàm phát âm với class playing
function playSound(audioUrl, word) {
  const phoneticBtn = document.getElementById("PhoneticBtn");
  const icon = phoneticBtn.querySelector("i");

  // Thêm class playing và thay đổi icon khi bắt đầu
  phoneticBtn.classList.add("playing");
  icon.classList.remove("fa-volume-high");
  icon.classList.add("fa-spinner", "fa-spin");

  if (audioUrl) {
    const audio = new Audio(audioUrl);
    audio.play().catch(err => {
      console.warn("Không thể phát audio, dùng SpeechSynthesis:", err);
      // Nếu lỗi, fallback sang SpeechSynthesis
      const utter = new SpeechSynthesisUtterance(word);
      utter.lang = "en-US";
      speechSynthesis.speak(utter);

      // Theo dõi trạng thái của SpeechSynthesis
      utter.onstart = () => {
        phoneticBtn.classList.add("playing");
        icon.classList.remove("fa-volume-high");
        icon.classList.add("fa-spinner", "fa-spin");
      };
      utter.onend = () => {
        phoneticBtn.classList.remove("playing");
        icon.classList.remove("fa-spinner", "fa-spin");
        icon.classList.add("fa-volume-high");
      };
    });

    // Theo dõi trạng thái của audio
    audio.onplay = () => {
      phoneticBtn.classList.add("playing");
      icon.classList.remove("fa-volume-high");
      icon.classList.add("fa-spinner", "fa-spin");
    };
    audio.onended = () => {
      phoneticBtn.classList.remove("playing");
      icon.classList.remove("fa-spinner", "fa-spin");
      icon.classList.add("fa-volume-high");
    };
  } else {
    const utter = new SpeechSynthesisUtterance(word);
    utter.lang = "en-US";
    speechSynthesis.speak(utter);

    // Theo dõi trạng thái của SpeechSynthesis
    utter.onstart = () => {
      phoneticBtn.classList.add("playing");
      icon.classList.remove("fa-volume-high");
      icon.classList.add("fa-spinner", "fa-spin");
    };
    utter.onend = () => {
      phoneticBtn.classList.remove("playing");
      icon.classList.remove("fa-spinner", "fa-spin");
      icon.classList.add("fa-volume-high");
    };
  }
}